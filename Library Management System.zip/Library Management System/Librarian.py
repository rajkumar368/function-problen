# -*- coding: utf-8 -*-
from User import User
from Library import Library
class Librarian(User):
    def __init__(self,username,password,name,email,mobile,address,librarian_id):
        super().__init__(username,password,name,email,mobile,address)
        self.librarian_id = librarian_id
       
        
    def add_book(self,book_name,quantity,author,rack,publish_date,pages):
# add new_book in the library
        if quantity>0:
            if book_name in Library.Count_book_dict.keys():
                Library.Count_book_dict[book_name][0]+=quantity
            else:
                Library.Count_book_dict.update({book_name:[quantity,author,publish_date,pages]})
                print("book has been added to library")
        else:
            print("please Enter postive integer number")
            
            
    def removeBook(self,book_name,quantity,author,rack,publish_date,pages):
        if quantity>0:
            if book_name in Library.Count_book_dict.keys():
                if Library.Count_book_dict[book_name][0]>=1:
                    Library.Count_book_dict[book_name][0]-=quantity
                    if Library.Count_book_dict[book_name][0] < 0:
                        Library.Count_book_dict[book_name][0]+=quantity
                        print("please enter correct quantity of book. we have only {} books of {}".format(Library.Count_book_dict[book_name][0],book_name))
                    else:
                        print("book remove successfully")
                else:
                    Library.Count_book_dict.pop(book_name)
                    print("sorry we don't have any books os {} in our libraray".format(book_name))
            else:
                print("please Enter correct book_name or quantity")
        else:
            print("please Enter postive integer number")
